﻿#include "Board.h"
#include <iostream>
#include "Player.h"
#include "Enemy.h"
#include "EnemySpawner.h"
#include <cstdlib>
#include <queue>
#include <set>

Board::Board(int width, int height)
    : width(width), height(height), grid(height, std::vector<Cell>(width))
{
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {

            int r = std::rand() % 100;

            if (r < 10)
                grid[y][x].setType(CellType::Wall);      // 10 % стен
            else if (r < 15)
                grid[y][x].setType(CellType::Slow);      // 5 % замедляющих
            else
                grid[y][x].setType(CellType::Normal);    // остальное — обычные
        }
    }
}

Board::Board(const Board& other)
    : width(other.width), height(other.height), grid(other.grid) {
}

Board::Board(Board&& other) noexcept
    : width(other.width), height(other.height), grid(std::move(other.grid)) {
    other.width = 0;
    other.height = 0;
}

Board& Board::operator=(const Board& other) {
    if (this != &other) {
        width = other.width;
        height = other.height;
        grid = other.grid;
    }
    return *this;
}

Board& Board::operator=(Board&& other) noexcept {
    if (this != &other) {
        width = other.width;
        height = other.height;
        grid = std::move(other.grid);
        other.width = 0;
        other.height = 0;
    }
    return *this;
}

bool Board::isInside(int x, int y) const {
    return x >= 0 && y >= 0 && x < width && y < height;
}

Cell& Board::getCell(int x, int y) {
    return grid[y][x];
}

const Cell& Board::getCell(int x, int y) const {
    return grid[y][x];
}

void Board::placeEntity(std::shared_ptr<Entity> entity, int x, int y) {
    if (!isInside(x, y))
        throw std::out_of_range("Invalid position for entity");

    Cell& cell = getCell(x, y);

    if (cell.isOccupied())
        throw std::logic_error("Cell is already occupied");

    cell.setEntity(entity);
    entity->setPosition(x, y);
}

bool Board::isReachable(const std::pair<int, int>& pos) const {
    if (!isInside(pos.first, pos.second) || grid[pos.first][pos.second].isOccupied())
        return false;

    const std::vector<std::pair<int, int>> dirs = { {1,0},{-1,0},{0,1},{0,-1} };
    std::queue<std::pair<int, int>> q;
    std::set<std::pair<int, int>> visited;

    q.push(pos);
    visited.insert(pos);

    int steps = 0;
    while (!q.empty() && steps < 8) {
        auto [x, y] = q.front();
        q.pop();
        ++steps;

        for (auto [dx, dy] : dirs) {
            int nx = x + dx, ny = y + dy;
            if (!isInside(nx, ny) || visited.count({ nx, ny })) continue;
            if (!grid[nx][ny].isOccupied()) return true;
            visited.insert({ nx, ny });
        }
    }
    return false;
}

std::pair<int, int> Board::getRandomFreeCell() const {
    int x, y;
    do {
        x = std::rand() % width;
        y = std::rand() % height;
    } while (grid[y][x].isOccupied() || grid[y][x].getType() == CellType::Wall);
    return { x, y };
}