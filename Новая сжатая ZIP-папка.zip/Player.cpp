#include "Player.h"
#include <iostream>


void Player::takeDamage(int dmg) {
    health -= dmg;
    if (health < 0) health = 0;
	std::cout << "Player took " << dmg << " damage! HP left: " << health << "\n";
}

void Player::addExperience(unsigned int exp) {
    experience += exp;
    std::cout << "Player gained " << exp << " XP! Total: " << experience << "\n";
}

void Player::takeTurn() {
    std::cout << "Player turn.\n";
}

void Player::switchMode() {
    if (attackMode == AttackMode::Melee) {
        attackMode = AttackMode::Ranged;
    }
    else {
        attackMode = AttackMode::Melee;
    }
}

