#include "SaveManager.h"
#include "json.hpp"
#include <fstream>
#include <stdexcept>
#include <iostream>

using json = nlohmann::json;

void SaveManager::saveGame(const Game& game, const std::string& filename) {
    json j;

    const Board& board = game.getBoard();

    // === META ===
    j["meta"]["turn"] = game.getTurnCounter();
    j["meta"]["seed"] = game.getSeed();
    j["meta"]["width"] = board.getWidth();
    j["meta"]["height"] = board.getHeight();

    // === BOARD CELLS ===
    for (int y = 0; y < board.getHeight(); ++y) {
        for (int x = 0; x < board.getWidth(); ++x) {

            const Cell& c = board.getCell(x, y);

            std::string t;
            switch (c.getType()) {
            case CellType::Normal: t = "normal"; break;
            case CellType::Wall:   t = "wall";   break;
            case CellType::Slow:   t = "slow";   break;
            }

            j["board"].push_back({
                {"x", x},
                {"y", y},
                {"type", t}
                });
        }
    }

    // === PLAYER ===
    if (auto p = game.getPlayer()) {
        auto [px, py] = p->getPosition();

        j["player"]["x"] = px;
        j["player"]["y"] = py;
        j["player"]["hp"] = p->getHealth();
        j["player"]["attack_mode"] =
            (p->getAttackMode() == AttackMode::Melee ? "melee" : "ranged");

        // spells
        for (auto& sp : p->getSpellHand().getSpells()) {
            j["player"]["spells"].push_back(sp->name());
        }
    }

    // === ENEMIES ===
    for (auto& e : game.getEnemies()) {
        auto [ex, ey] = e->getPosition();
        j["enemies"].push_back({
            {"x", ex},
            {"y", ey},
            {"hp", e->getHealth()}
            });
    }

    // === SPAWNERS ===
    for (auto& s : game.getSpawners()) {
        auto [sx, sy] = s->getPosition();
        j["spawners"].push_back({
            {"x", sx},
            {"y", sy}
            });
    }

    // === TOWERS ===
    for (auto& t : game.getTowers()) {
        auto [tx, ty] = t->getPosition();

        j["towers"].push_back({
            {"x", tx},
            {"y", ty},
            {"range", t->getRange()}
            });
    }

    // === WRITE FILE ===
    std::ofstream file(filename);
    if (!file)
        throw std::runtime_error("Cannot open save file");

    file << std::setw(4) << j;

    std::cout << "[SaveManager] Saved to " << filename << "\n";
}

void SaveManager::loadGame(Game& game, const std::string& filename) {
    std::ifstream file(filename);
    if (!file)
        throw std::runtime_error("Save file not found: " + filename);

    json j;
    file >> j;

    int seed = j["meta"]["seed"];
    int savedTurn = j["meta"]["turn"];

    game.clearEntities();

    game.setSeed(seed);

    game.generateBoard();

    game.clearEntities();

    auto p = std::make_shared<Player>();
    p->setHealth(j["player"]["hp"]);
    p->setAttackMode(j["player"]["attack_mode"] == "melee"
        ? AttackMode::Melee : AttackMode::Ranged);

    auto& hand = p->getSpellHand();
    hand.clear();

    for (auto& s : j["player"]["spells"]) {
        std::string nm = s.get<std::string>();
        if (nm == "Firebolt") hand.addSpell(std::make_shared<Firebolt>(5, 3));
        if (nm == "EnhanceSpell") hand.addSpell(std::make_shared<EnhanceSpell>());
    }

    game.setPlayer(p);
    game.placeEntityAt(p, j["player"]["x"], j["player"]["y"]);

    for (auto& e : j["enemies"]) {
        auto enemy = std::make_shared<Enemy>();
        enemy->setHealth(e["hp"]);
        game.addEnemy(enemy);
        game.placeEntityAt(enemy, e["x"], e["y"]);
    }

    for (auto& s : j["spawners"]) {
        auto spawner = std::make_shared<EnemySpawner>();
        game.addSpawner(spawner);
        game.placeEntityAt(spawner, s["x"], s["y"]);
    }

    for (auto& t : j["towers"]) {
        int x = t["x"];
        int y = t["y"];
        int range = t["range"];

        auto tower = std::make_shared<EnemyTower>(
            std::make_shared<Firebolt>(5, 3),
            range
        );
		tower->setPosition(x, y);
        game.addTower(tower);
    }


    game.setTurnCounter(savedTurn);

    std::cout << "[SaveManager] Loaded by regenerating world from seed.\n";
}
